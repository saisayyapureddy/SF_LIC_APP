import { LightningElement } from 'lwc';

export default class Bmi extends LightningElement {}